
n = int(raw_input("Enter number till pattern is to be printed: "))
for i in range (0,n):
	print (n-i)*" ",
	print (i)*"* "
	

	
