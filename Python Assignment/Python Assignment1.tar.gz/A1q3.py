pi=3.14
r = int(raw_input("Enter the radius of circle: "))
print "Area of the circle is: ",pi*(r**2) 
print "Circumference of the circle is: ", 2*pi*r
