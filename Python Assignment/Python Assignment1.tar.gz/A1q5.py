name = raw_input("Enter name of student:")
class1 = int(raw_input("Enter the class in which studentis studying:"))
roll = int(raw_input("Enter Roll no. of student:"))
m1 = raw_input("Enter marks in 1st subject:")
m2 = raw_input("Enter marks in 2nd subject:")
m3 = raw_input("Enter marks in 3rd subject:")

print "Name of the student is",name
print "Class of the student is Rs.",class1
print "Roll no. of the student is",roll
print "Marks in three subjects are",(m1,m2,m3)
