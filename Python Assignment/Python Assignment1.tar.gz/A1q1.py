n = int(raw_input("Enter a number:"))
print "Cube of the number is: ",n**3
