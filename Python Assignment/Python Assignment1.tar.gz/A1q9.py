#to i/p no. day of the week and print name of the day
n = int(raw_input("Enter day number: "))
if(n == 1):
	print "monday"
elif(n == 2):
	print "tuesday"
elif(n == 3):
	print "wednesday"
elif(n == 4):
	print "thursday"
elif(n == 5):
	print "friday"
elif(n == 6):
	print "saturday"
elif(n == 7):
	print "sunday"
else:
	print "Invalid entry!"
