b = raw_input("Enter book name: ") #book name
q = int(raw_input("Enter quantity of item: ")) #quantity
r = input("Enter rate per item: ") #rate per item
y = input("Year of publishing: ") #year of publishing
t = q*r/100
if (t>100):
	if (r >= 500 and r <=1000):
		if (y%4==0 or y%400==0):
			print "Item name: ",b
			print "Quantity of items: ",q
			print "rate per item: ",r
			print "year of publishing: ",y
		else: 
			print " non leap year"
	else: 
		print "Rate is not in range"
else:
	print "Total amount is less than 100"
