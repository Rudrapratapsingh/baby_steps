t = int(raw_input("Enter temperature in degree celcius:"))
print "Temperature in Farhenheit is: ", (t*1.8 +32)
