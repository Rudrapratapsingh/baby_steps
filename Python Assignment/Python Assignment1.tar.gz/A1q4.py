name = raw_input("Enter name of employee:")
salary = int(raw_input("Enter salary of employee:"))
bonus = int(raw_input("Enter bonus of employee:"))

print "Name of the employee is",name
print "Salary of the employee is Rs.",salary
print "Bonus employee got is Rs.",bonus
print "Final salary of the employee is ",(salary+bonus)
