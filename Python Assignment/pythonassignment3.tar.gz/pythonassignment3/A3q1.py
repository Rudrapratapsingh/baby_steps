string = raw_input('Enter any string: ')
word = string.split();
length = len(word);
print length





